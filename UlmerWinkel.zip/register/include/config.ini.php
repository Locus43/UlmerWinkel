;<?php die(); ?>
[database]
db_name = null
db_user = null
db_password = null
db_host = null